"""Search, download and mosaic Sentinel-2 RGB scenes for city/date tasks."""

from __future__ import annotations

import csv
import json
import math
import re
import threading
import time
from collections import defaultdict
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Callable

import numpy as np
import rasterio
import requests
from PIL import Image
from pyproj import Transformer
from rasterio.enums import ColorInterp, Resampling
from rasterio.features import rasterize
from rasterio.transform import from_origin
from rasterio.vrt import WarpedVRT
from rasterio.warp import transform_bounds
from rasterio.windows import Window, bounds as window_bounds
from shapely.geometry import shape
from shapely.ops import unary_union
from shapely.ops import transform as shapely_transform
from scipy.ndimage import binary_dilation

STAC = "https://earth-search.aws.element84.com/v1/search"
GEOCODER = "https://nominatim.openstreetmap.org/search"
USER_AGENT = "CodexSentinelCityDownloader/1.0 (personal desktop GIS tool)"
Progress = Callable[[str, str, float], None]
MIN_MAIN_COVERAGE = 0.95  # The low-cloud scenes must form most of the city.
EDGE_CLOUD_MARGIN = 1.0   # A same-day edge scene may exceed the main limit by 1 point.


class Stopped(Exception):
    pass


@dataclass(frozen=True)
class Task:
    city: str
    start: str
    end: str
    max_cloud: float = 20.0
    pick: str = "latest"  # latest, least_cloud, or cloud_free
    mosaic: bool = True
    max_scenes: int = 12


def safe_name(value: str) -> str:
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value).strip(" .")[:90] or "region"


def check_stop(stop: threading.Event) -> None:
    if stop.is_set():
        raise Stopped("已停止；未完成的下载可继续。")


def datav_boundary(province: str, city_name: str, session: requests.Session,
                   stop: threading.Event) -> dict | None:
    """Use the region picker source if OSM has no city polygon."""
    base = "https://geo.datav.aliyun.com/areas_v3/bound/"

    def fetch(code: str) -> dict:
        check_stop(stop)
        response = session.get(base + code + ".json", timeout=40)
        response.raise_for_status()
        return response.json()

    national = fetch("100000_full")
    parent = next((f for f in national.get("features", [])
                   if f.get("properties", {}).get("name") == province), None)
    if parent is None:
        return None
    province_code = parent["properties"]["adcode"]
    if city_name == province:
        result = fetch(str(province_code))
        features = result.get("features", [])
        if not features:
            return None
        return {"type": "Feature", "geometry": features[0]["geometry"],
                "properties": {"query": province, "display_name": province,
                               "adcode": province_code, "source": "DataV GeoAtlas"}}
    children = fetch(str(province_code) + "_full")
    city = next((f for f in children.get("features", [])
                 if f.get("properties", {}).get("name") == city_name), None)
    if city is None:
        return None
    city_code = city["properties"]["adcode"]
    result = fetch(str(city_code))
    features = result.get("features", [])
    if not features:
        return None
    return {"type": "Feature", "geometry": features[0]["geometry"],
            "properties": {"query": province + city_name,
                           "display_name": city_name + ", " + province,
                           "adcode": city_code, "source": "DataV GeoAtlas"}}


def geocode(city: str, cache_dir: Path, session: requests.Session, stop: threading.Event) -> dict:
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache = cache_dir / (safe_name(city) + ".geojson")
    if cache.exists():
        return json.loads(cache.read_text(encoding="utf-8"))
    check_stop(stop)
    regions_file = Path(__file__).with_name("china_regions.json")
    regions = json.loads(regions_file.read_text(encoding="utf-8")) if regions_file.exists() else {}
    province = next((name for name in sorted(regions, key=len, reverse=True)
                     if city == name or city.startswith(name)), None)
    city_name = (city[len(province):] or province) if province else city
    queries = ([{"city": city_name, "state": province, "country": "中国"},
                {"q": f"{city_name}, {province}, 中国"},
                {"q": f"{city_name}, 中国"}]
               if province and city_name != province else [{"q": city}, {"q": f"{city}, 中国"}])
    matches = []
    for index, params in enumerate(queries):
        check_stop(stop)
        params.update({"format": "json", "polygon_geojson": 1, "limit": 10, "addressdetails": 1})
        try:
            response = session.get(GEOCODER, params=params, timeout=40)
            response.raise_for_status()
            results = response.json()
        except requests.RequestException:
            time.sleep(1.1)
            continue
        matches = [r for r in results if r.get("type") == "administrative"
                   and r.get("geojson", {}).get("type") in ("Polygon", "MultiPolygon")]
        if matches:
            break
        time.sleep(1.1)
    if not matches:
        if province:
            fallback = datav_boundary(province, city_name, session, stop)
            if fallback:
                cache.write_text(json.dumps(fallback, ensure_ascii=False), encoding="utf-8")
                return fallback
        raise ValueError(f"未能取得“{city}”的行政边界；请稍后重试该任务。")
    chosen = next((r for r in matches if r.get("addresstype") in
                   ("city", "town", "municipality", "county", "state_district")), matches[0])
    data = {"type": "Feature", "geometry": chosen["geojson"], "properties": {
        "query": city, "display_name": chosen["display_name"],
        "osm_id": chosen.get("osm_id"), "source": "© OpenStreetMap contributors / Nominatim"}}
    cache.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    time.sleep(1.1)  # Public Nominatim limit: at most one request per second.
    return data


def search_scenes(city_geometry, task: Task, session: requests.Session,
                  stop: threading.Event, progress: Progress) -> list[dict]:
    payload = {"collections": ["sentinel-2-c1-l2a"], "bbox": list(city_geometry.bounds),
               "datetime": f"{task.start}T00:00:00Z/{task.end}T23:59:59Z",
               "query": {"eo:cloud_cover": {"lt": 100.00001 if task.pick == "cloud_free"
                                            else task.max_cloud}}, "limit": 1000}
    items: list[dict] = []
    for page in range(100):
        check_stop(stop)
        for attempt in range(4):
            check_stop(stop)
            try:
                response = session.post(STAC, json=payload, timeout=(20, 90))
                response.raise_for_status()
                result = response.json()
                break
            except (requests.RequestException, ValueError):
                if attempt == 3:
                    raise
                progress("search", f"影像目录暂时无响应，正在重试（{attempt + 1}/3）", 0)
                time.sleep(2 * (attempt + 1))
        items.extend(result.get("features", []))
        progress("search", f"检索影像：第 {page + 1} 页，已找到 {len(items)} 景", 0)
        next_link = next((link for link in result.get("links", []) if link.get("rel") == "next"), None)
        if not next_link:
            return items
        payload = next_link.get("body")
        if not payload:
            raise RuntimeError("影像目录返回了无法读取的分页链接。")
    raise RuntimeError("检索结果超过 100 页；请缩短时间范围。")


def choose_scenes(items: list[dict], city_geometry, task: Task,
                  strict_limit: float | None = None) -> tuple[list[dict], str, float]:
    grouped: dict[str, list[tuple[dict, object]]] = defaultdict(list)
    for item in items:
        if "visual" not in item.get("assets", {}):
            continue
        inter = city_geometry.intersection(shape(item["geometry"]))
        if inter.area > 0:
            grouped[item["properties"]["datetime"][:10]].append((item, inter))
    candidates = []
    for day, scenes in grouped.items():
        uncovered = city_geometry
        selected: list[tuple[dict, float]] = []
        pools = ([scenes] if strict_limit is None else
                 [[pair for pair in scenes
                   if float(pair[0]["properties"].get("eo:cloud_cover", 100)) < strict_limit], scenes])
        strict_coverage = 0.0
        for pool_index, pool in enumerate(pools):
            while uncovered.area / city_geometry.area > 0.00001:
                used = {entry[0]["id"] for entry in selected}
                gains = [(inter.intersection(uncovered).area, item, inter)
                         for item, inter in pool if item["id"] not in used]
                if not gains:
                    break
                gain, item, inter = max(gains, key=lambda x: (
                    x[0], -float(x[1]["properties"].get("eo:cloud_cover", 100)), x[1]["id"]))
                if gain <= city_geometry.area * 0.000001:
                    break
                selected.append((item, gain))
                uncovered = uncovered.difference(inter)
            if strict_limit is not None and pool_index == 0:
                strict_coverage = 1 - uncovered.area / city_geometry.area
        coverage = 1 - uncovered.area / city_geometry.area
        if coverage < 0.995:
            candidates.append((day, coverage, 100.0, []))
            continue
        cloud = sum(item["properties"].get("eo:cloud_cover", 100) * gain for item, gain in selected) / sum(gain for _, gain in selected)
        if strict_limit is not None and (strict_coverage < MIN_MAIN_COVERAGE or cloud >= strict_limit):
            candidates.append((day, coverage, cloud, []))
            continue
        candidates.append((day, coverage, cloud, [item for item, _ in selected]))
    complete = [c for c in candidates if c[3]]
    if not complete:
        best = max((c[1] for c in candidates), default=0)
        raise ValueError(
            f"此时间段没有每景云量低于 {task.max_cloud:g}% 且覆盖全城的单日影像"
            f"（最佳覆盖 {best:.1%}）。请扩大时间范围或调高云量上限。")
    if task.pick == "least_cloud":
        day, coverage, cloud, selected = min(complete, key=lambda c: (c[2], -date.fromisoformat(c[0]).toordinal()))
    else:
        day, coverage, cloud, selected = max(complete, key=lambda c: (c[0], -c[2]))
    return selected, day, coverage


def valid_tiff(path: Path, expected_size: int | None = None, bands: int = 3) -> bool:
    if not path.exists() or (expected_size and path.stat().st_size != expected_size):
        return False
    try:
        with rasterio.open(path) as image:
            return image.count == bands and image.width > 1000 and image.height > 1000
    except rasterio.errors.RasterioIOError:
        return False


def download_scene(item: dict, folder: Path, session: requests.Session,
                   stop: threading.Event, progress: Progress, asset_key: str = "visual") -> Path:
    asset = item["assets"][asset_key]
    bands = 1 if asset_key == "scl" else 3
    target = folder / (item["id"] + ("_SCL.tif" if asset_key == "scl" else "_RGB.tif"))
    partial = folder / (target.name + ".part")
    expected = int(asset.get("file:size") or 0)
    if valid_tiff(target, expected or None, bands):
        progress("download", f"已存在：{target.name}", 1)
        return target
    if target.exists():
        target.replace(partial)
    for attempt in range(4):
        check_stop(stop)
        offset = partial.stat().st_size if partial.exists() else 0
        if expected and offset == expected and valid_tiff(partial, expected, bands):
            partial.replace(target)
            return target
        if expected and offset > expected:
            partial.unlink()
            offset = 0
        headers = {"Range": f"bytes={offset}-"} if offset else {}
        try:
            with session.get(asset["href"], headers=headers, stream=True, timeout=(30, 120)) as response:
                response.raise_for_status()
                if offset and response.status_code == 206:
                    if not response.headers.get("Content-Range", "").startswith(f"bytes {offset}-"):
                        raise RuntimeError("续传位置不匹配")
                    mode = "ab"
                else:
                    mode = "wb"
                total = expected or offset + int(response.headers.get("Content-Length") or 0)
                with partial.open(mode) as output:
                    last = 0.0
                    for chunk in response.iter_content(chunk_size=1024 * 1024):
                        check_stop(stop)
                        if chunk:
                            output.write(chunk)
                        now = time.monotonic()
                        if now - last > 0.25:
                            progress("download", f"下载 {target.name}: {output.tell()/1e6:.0f}/{total/1e6:.0f} MB",
                                     min(1, output.tell() / total) if total else 0)
                            last = now
            if not valid_tiff(partial, expected or None, bands):
                raise ValueError("下载文件大小或 GeoTIFF 格式有误")
            partial.replace(target)
            progress("download", f"完成：{target.name}", 1)
            return target
        except Stopped:
            raise
        except Exception:
            if attempt == 3:
                raise
            time.sleep(2 * (attempt + 1))
    raise AssertionError("unreachable")


def mosaic_scenes(paths: list[Path], city_geometry, output: Path, preview: Path,
                  stop: threading.Event, progress: Progress) -> None:
    with rasterio.open(paths[0]) as first:
        crs = first.crs
    left, bottom, right, top = transform_bounds("EPSG:4326", crs, *city_geometry.bounds, densify_pts=21)
    left, bottom = math.floor(left / 10) * 10, math.floor(bottom / 10) * 10
    right, top = math.ceil(right / 10) * 10, math.ceil(top / 10) * 10
    width, height = round((right - left) / 10), round((top - bottom) / 10)
    if width * height > 10_000_000_000:
        raise ValueError(f"区域过大（{width}×{height} 像素），无法保存为一张影像。")
    transform = from_origin(left, top, 10, 10)
    profile = {"driver": "GTiff", "width": width, "height": height, "count": 3,
               "dtype": "uint8", "crs": crs, "transform": transform, "nodata": 0,
               "tiled": True, "blockxsize": 512, "blockysize": 512,
               "compress": "DEFLATE", "predictor": 2, "zlevel": 4, "BIGTIFF": "IF_SAFER",
               "photometric": "RGB"}
    temporary = output.with_suffix(".building.tif")
    datasets = [rasterio.open(path) for path in paths]
    vrts = [WarpedVRT(ds, crs=crs, transform=transform, width=width, height=height,
                      nodata=0, resampling=Resampling.nearest) for ds in datasets]
    bounds = [transform_bounds(ds.crs, crs, *ds.bounds, densify_pts=5) for ds in datasets]
    total = math.ceil(width / 512) * math.ceil(height / 512)
    done = 0
    try:
        with rasterio.Env(GDAL_CACHEMAX=256), rasterio.open(temporary, "w", **profile) as dst:
            dst.colorinterp = (ColorInterp.red, ColorInterp.green, ColorInterp.blue)
            for y in range(0, height, 512):
                for x in range(0, width, 512):
                    check_stop(stop)
                    window = Window(x, y, min(512, width - x), min(512, height - y))
                    wx0, wy0, wx1, wy1 = window_bounds(window, transform)
                    rgb = np.zeros((3, int(window.height), int(window.width)), dtype=np.uint8)
                    filled = np.zeros((int(window.height), int(window.width)), dtype=bool)
                    for vrt, b in zip(vrts, bounds):
                        if b[2] <= wx0 or b[0] >= wx1 or b[3] <= wy0 or b[1] >= wy1:
                            continue
                        put = (vrt.dataset_mask(window=window) > 0) & ~filled
                        if put.any():
                            data = vrt.read(window=window)
                            rgb[:, put] = data[:, put]
                            filled[put] = True
                        if filled.all():
                            break
                    dst.write(rgb, window=window)
                    done += 1
                    if done % 5 == 0 or done == total:
                        progress("mosaic", f"拼接 {done}/{total} 块", done / total)
        temporary.replace(output)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    finally:
        for vrt in vrts:
            vrt.close()
        for ds in datasets:
            ds.close()
    with rasterio.open(output) as ds:
        preview_width = 1800
        preview_height = round(height * preview_width / width)
        image = ds.read(out_shape=(3, preview_height, preview_width), resampling=Resampling.bilinear)
    Image.fromarray(np.moveaxis(image, 0, 2), "RGB").save(preview, quality=88, optimize=True)


def choose_clear_scenes(items: list[dict], city_geometry, folder: Path,
                        session: requests.Session, stop: threading.Event,
                        progress: Progress, max_scenes: int = 12) -> tuple[list[dict], float, str, int]:
    """Keep the clearest complete overpass as the base, then patch only its cloudy pixels."""
    candidates = [item for item in items if "visual" in item.get("assets", {})
                  and "scl" in item["assets"]
                  and city_geometry.intersects(shape(item["geometry"]))]
    if not candidates:
        raise ValueError("所选时段没有可用的自然色影像和云分类图。")
    with rasterio.open(download_scene(candidates[0], folder, session, stop, progress, "scl")) as first:
        crs = first.crs
    project = Transformer.from_crs("EPSG:4326", crs, always_xy=True).transform
    projected = shapely_transform(project, city_geometry)
    left, bottom, right, top = projected.bounds
    # Limit memory for large cities while keeping 100 m sampling for smaller ones.
    resolution = max(100, math.ceil(math.sqrt((right - left) * (top - bottom) / 750_000) / 10) * 10)
    width = math.ceil((right - left) / resolution)
    height = math.ceil((top - bottom) / resolution)
    if width * height > 1_000_000:
        raise ValueError("区域过大，无法在当前模式下筛选去云影像。")
    transform = from_origin(left, top, resolution, resolution)
    city_mask = rasterize([(projected, 1)], out_shape=(height, width),
                          transform=transform, fill=0, dtype="uint8").astype(bool)
    clear_masks: list[np.ndarray] = []
    for index, item in enumerate(candidates, 1):
        check_stop(stop)
        path = download_scene(item, folder, session, stop, progress, "scl")
        with rasterio.open(path) as src:
            with WarpedVRT(src, crs=crs, transform=transform, width=width, height=height,
                           resampling=Resampling.nearest, nodata=0) as vrt:
                scl = vrt.read(1)
        clear_masks.append(city_mask & np.isin(scl, (4, 5, 6)))
        progress("search", f"检查云层 {index}/{len(candidates)} 景", index / len(candidates))
    city_pixels = int(city_mask.sum())
    groups: dict[str, list[int]] = defaultdict(list)
    for index, item in enumerate(candidates):
        groups[item["id"].split("_")[2]].append(index)
    base_key = max(groups, key=lambda key: (
        int(np.count_nonzero(np.logical_or.reduce([clear_masks[i] for i in groups[key]]))),
        -sum(float(candidates[i]["properties"].get("eo:cloud_cover", 100)) for i in groups[key]) / len(groups[key]),
        key))
    selected: list[dict] = []
    covered = np.zeros_like(city_mask)
    remaining_base = set(groups[base_key])
    remaining_patch = set(range(len(candidates))) - remaining_base
    for remaining, label in ((remaining_base, "主日期"), (remaining_patch, "局部补云")):
        while remaining and len(selected) < max_scenes:
            check_stop(stop)
            best = max(remaining, key=lambda i: (
                int(np.count_nonzero(clear_masks[i] & ~covered)),
                -float(candidates[i]["properties"].get("eo:cloud_cover", 100)),
                candidates[i]["properties"]["datetime"],
                candidates[i]["id"]))
            gain = int(np.count_nonzero(clear_masks[best] & ~covered))
            if gain == 0:
                break
            selected.append(candidates[best])
            covered |= clear_masks[best]
            remaining.remove(best)
            coverage = int(np.count_nonzero(covered)) / city_pixels
            progress("search", f"{label}已选 {len(selected)} 景，市域清晰覆盖约 {coverage:.1%}", coverage)
            if label == "局部补云" and coverage >= 0.995:
                break
        if label == "主日期":
            base_count = len(selected)
            if int(np.count_nonzero(covered)) / city_pixels >= 0.995:
                break
    if not selected:
        raise ValueError("所选时间范围内，城市区域没有可用的清晰像素。")
    return selected, int(np.count_nonzero(covered)) / city_pixels, base_key, base_count


def mosaic_clear_scenes(items: list[dict], rgb_paths: list[Path], scl_paths: list[Path],
                        city_geometry, output: Path, preview: Path,
                        stop: threading.Event, progress: Progress) -> None:
    """Fill each output pixel only from a clear Sentinel-2 observation."""
    with rasterio.open(rgb_paths[0]) as first:
        crs = first.crs
    left, bottom, right, top = transform_bounds("EPSG:4326", crs, *city_geometry.bounds, densify_pts=21)
    left, bottom = math.floor(left / 10) * 10, math.floor(bottom / 10) * 10
    right, top = math.ceil(right / 10) * 10, math.ceil(top / 10) * 10
    width, height = round((right - left) / 10), round((top - bottom) / 10)
    if width * height > 10_000_000_000:
        raise ValueError(f"区域过大（{width}×{height} 像素），无法保存为一张影像。")
    transform = from_origin(left, top, 10, 10)
    profile = {"driver": "GTiff", "width": width, "height": height, "count": 3,
               "dtype": "uint8", "crs": crs, "transform": transform, "nodata": 0,
               "tiled": True, "blockxsize": 512, "blockysize": 512,
               "compress": "DEFLATE", "predictor": 2, "zlevel": 4,
               "BIGTIFF": "IF_SAFER", "photometric": "RGB"}
    temporary = output.with_suffix(".building.tif")
    sources = [(rasterio.open(rgb), rasterio.open(scl)) for rgb, scl in zip(rgb_paths, scl_paths)]
    vrts = [(WarpedVRT(rgb, crs=crs, transform=transform, width=width, height=height,
                       nodata=0, resampling=Resampling.nearest),
             WarpedVRT(scl, crs=crs, transform=transform, width=width, height=height,
                       nodata=0, resampling=Resampling.nearest)) for rgb, scl in sources]
    bounds = [transform_bounds(rgb.crs, crs, *rgb.bounds, densify_pts=5) for rgb, _ in sources]
    total = math.ceil(width / 512) * math.ceil(height / 512)
    done = 0
    try:
        with rasterio.Env(GDAL_CACHEMAX=256), rasterio.open(temporary, "w", **profile) as dst:
            dst.colorinterp = (ColorInterp.red, ColorInterp.green, ColorInterp.blue)
            for y in range(0, height, 512):
                for x in range(0, width, 512):
                    check_stop(stop)
                    window = Window(x, y, min(512, width - x), min(512, height - y))
                    wx0, wy0, wx1, wy1 = window_bounds(window, transform)
                    rgb = np.zeros((3, int(window.height), int(window.width)), dtype=np.uint8)
                    filled = np.zeros((int(window.height), int(window.width)), dtype=bool)
                    for (rgb_vrt, scl_vrt), b in zip(vrts, bounds):
                        if b[2] <= wx0 or b[0] >= wx1 or b[3] <= wy0 or b[1] >= wy1:
                            continue
                        scl = scl_vrt.read(1, window=window)
                        clear = np.isin(scl, (4, 5, 6))
                        # Keep the uncertain cloud boundary out of the final image.
                        obscured = np.isin(scl, (3, 7, 8, 9, 10))
                        clear &= ~binary_dilation(obscured, iterations=2)
                        put = clear & ~filled & (rgb_vrt.dataset_mask(window=window) > 0)
                        if put.any():
                            data = rgb_vrt.read(window=window)
                            rgb[:, put] = data[:, put]
                            filled[put] = True
                        if filled.all():
                            break
                    dst.write(rgb, window=window)
                    done += 1
                    if done % 5 == 0 or done == total:
                        progress("mosaic", f"去云拼接 {done}/{total} 块", done / total)
        temporary.replace(output)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    finally:
        for rgb_vrt, scl_vrt in vrts:
            rgb_vrt.close()
            scl_vrt.close()
        for rgb, scl in sources:
            rgb.close()
            scl.close()
    with rasterio.open(output) as ds:
        preview_width = 1800
        preview_height = round(height * preview_width / width)
        image = ds.read(out_shape=(3, preview_height, preview_width), resampling=Resampling.bilinear)
    Image.fromarray(np.moveaxis(image, 0, 2), "RGB").save(preview, quality=88, optimize=True)


def output_city_coverage(output: Path, city_geometry) -> float:
    """Measure the produced raster's valid pixels within the city at 100 m spacing."""
    with rasterio.open(output) as ds:
        project = Transformer.from_crs("EPSG:4326", ds.crs, always_xy=True).transform
        projected = shapely_transform(project, city_geometry)
        sample_factor = max(10, math.ceil(math.sqrt(ds.width * ds.height / 1_000_000)))
        width = math.ceil(ds.width / sample_factor)
        height = math.ceil(ds.height / sample_factor)
        sample_transform = ds.transform * rasterio.Affine.scale(ds.width / width, ds.height / height)
        city_mask = rasterize([(projected, 1)], out_shape=(height, width),
                              transform=sample_transform, fill=0, dtype="uint8").astype(bool)
        valid = ds.dataset_mask(out_shape=(height, width), resampling=Resampling.nearest) > 0
    return int(np.count_nonzero(valid & city_mask)) / int(np.count_nonzero(city_mask))


def run_task(task: Task, root: Path, cache: Path, stop: threading.Event,
             progress: Progress) -> Path:
    date.fromisoformat(task.start)
    date.fromisoformat(task.end)
    if task.start > task.end:
        raise ValueError("开始日期晚于结束日期。")
    session = requests.Session()
    session.headers["User-Agent"] = USER_AGENT
    feature = geocode(task.city, cache, session, stop)
    city_geometry = shape(feature["geometry"])
    progress("search", f"已找到行政范围：{feature['properties']['display_name']}", 0)
    items = search_scenes(city_geometry, task, session, stop, progress)
    if task.pick == "cloud_free":
        folder = root / safe_name(task.city) / f"{task.start}_至_{task.end}" / "多日期去云"
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "行政边界.geojson").write_text(json.dumps(feature, ensure_ascii=False), encoding="utf-8")
        selected = []
        base_date = ""
        base_count = 0
        mode = "local_patch_v2"
        clear_coverage = 0.0
        nearly_clear = [item for item in items
                        if float(item["properties"].get("eo:cloud_cover", 100)) <= 1.0]
        if nearly_clear:
            try:
                candidate, day, footprint = choose_scenes(
                    nearly_clear, city_geometry,
                    Task(task.city, task.start, task.end, 1.0, "least_cloud", True))
                if footprint >= 0.999 and len(candidate) <= task.max_scenes:
                    selected = candidate
                    base_date = day
                    base_count = len(selected)
                    clear_coverage = footprint
                    mode = "clear_single_day"
                    progress("search", f"找到晴朗单日 {day}：{len(selected)} 景，直接拼接", 1)
            except ValueError:
                pass
        if not selected:
            progress("search", "没有覆盖全城的近乎无云单日影像，正在比较各日期并准备局部补云", 0)
            selected, clear_coverage, base_key, base_count = choose_clear_scenes(
                items, city_geometry, folder, session, stop, progress, task.max_scenes)
            base_date = f"{base_key[:4]}-{base_key[4:6]}-{base_key[6:8]}"
            progress("search", f"主日期 {base_date}；另选 {len(selected) - base_count} 景局部补云", 1)
        with (folder / "影像来源.csv").open("w", encoding="utf-8-sig", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["scene_id", "role", "acquisition_time", "scene_cloud_percent",
                             "direct_rgb_tif_url", "direct_scl_tif_url"])
            for index, item in enumerate(selected):
                writer.writerow([item["id"], "主日期" if index < base_count else "局部补云",
                                 item["properties"]["datetime"],
                                 item["properties"].get("eo:cloud_cover", ""),
                                 item["assets"]["visual"]["href"],
                                 item.get("assets", {}).get("scl", {}).get("href", "")])
        method = ("找到整城近乎无云的单日影像；直接拼接原始 RGB 瓦片，未做多日期补云。"
                  if mode == "clear_single_day" else
                  "先保留市域内最晴朗的一次拍摄，再仅用其他日期的清晰像素填补云区。")
        detail = ("全部影像来自同一天；整景云量很低，但不保证每个像素绝对无云。"
                  if mode == "clear_single_day" else
                  "局部补云使用 Sentinel-2 场景分类图；没有清晰观测的像素保持 NoData。")
        (folder / "去云说明.txt").write_text(
            f"时间范围：{task.start} 至 {task.end}\n"
            f"主日期：{base_date}\n"
            f"处理方式：{method}\n"
            f"选用影像：{len(selected)} 景\n"
            f"选片覆盖估计：{clear_coverage:.2%}\n"
            f"{detail}\n",
            encoding="utf-8")
        rgb_paths = []
        scl_paths = []
        for index, item in enumerate(selected, 1):
            check_stop(stop)
            progress("download", f"第 {index}/{len(selected)} 景：{item['id']}", 0)
            rgb_paths.append(download_scene(item, folder, session, stop, progress))
            if mode != "clear_single_day":
                scl_paths.append(download_scene(item, folder, session, stop, progress, "scl"))
        if not task.mosaic:
            return folder
        output = folder / (safe_name(task.city) + f"_{task.start}_至_{task.end}_多日期去云_10m.tif")
        preview = folder / (safe_name(task.city) + "_去云预览.jpg")
        selection_file = folder / "已拼接景号.json"
        selection = {"mode": mode, "scene_ids": [item["id"] for item in selected]}
        previous = (json.loads(selection_file.read_text(encoding="utf-8"))
                    if selection_file.exists() else None)
        if not valid_tiff(output) or previous != selection:
            if mode == "clear_single_day":
                mosaic_scenes(rgb_paths, city_geometry, output, preview, stop, progress)
            else:
                mosaic_clear_scenes(selected, rgb_paths, scl_paths, city_geometry,
                                    output, preview, stop, progress)
            selection_file.write_text(json.dumps(selection, ensure_ascii=False, indent=2),
                                      encoding="utf-8")
        actual_coverage = output_city_coverage(output, city_geometry)
        with (folder / "去云说明.txt").open("a", encoding="utf-8") as note:
            note.write(f"成品市域有效像素覆盖（100米采样）：{actual_coverage:.2%}\n")
            if actual_coverage < 0.995:
                note.write("若需减少留空，可扩大时间范围或提高最多景数后重新运行。\n")
        hint = "；可扩大时间或增加景数" if actual_coverage < 0.995 else ""
        progress("mosaic", f"完成：市域有效像素 {actual_coverage:.2%}{hint}", 1)
        return output
    edge_limit = task.max_cloud
    try:
        selected, day, coverage = choose_scenes(items, city_geometry, task)
    except ValueError as original_error:
        if task.pick != "least_cloud" or task.max_cloud >= 100:
            raise
        edge_limit = min(100.0, task.max_cloud + EDGE_CLOUD_MARGIN)
        progress("search", f"严格 {task.max_cloud:g}% 条件下未覆盖全城，检查同日边缘补景（最高 {edge_limit:g}%）", 0)
        extra_task = Task(task.city, task.start, task.end, edge_limit, task.pick,
                          task.mosaic, task.max_scenes)
        expanded = search_scenes(city_geometry, extra_task, session, stop, progress)
        try:
            selected, day, coverage = choose_scenes(
                expanded, city_geometry, task, strict_limit=task.max_cloud)
        except ValueError:
            raise ValueError(
                f"{original_error} 已检查同日边缘补景，仍无法在整城加权云量低于 "
                f"{task.max_cloud:g}% 的条件下补齐。") from None
    edge_count = sum(float(item["properties"].get("eo:cloud_cover", 100)) >= task.max_cloud
                     for item in selected)
    edge_note = f"；其中 {edge_count} 景为同日边缘补景" if edge_count else ""
    progress("search", f"选中 {day}：{len(selected)} 景，覆盖 {coverage:.2%}{edge_note}", 1)
    folder = root / safe_name(task.city) / f"{task.start}_至_{task.end}" / day
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "行政边界.geojson").write_text(json.dumps(feature, ensure_ascii=False), encoding="utf-8")
    with (folder / "影像来源.csv").open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["scene_id", "role", "acquisition_time", "cloud_percent", "direct_rgb_tif_url"])
        for item in selected:
            role = ("边缘补景" if float(item["properties"].get("eo:cloud_cover", 100)) >= task.max_cloud
                    else "晴朗主景")
            writer.writerow([item["id"], role, item["properties"]["datetime"],
                             item["properties"].get("eo:cloud_cover", ""), item["assets"]["visual"]["href"]])
    (folder / "选片说明.txt").write_text(
        f"日期：{day}\n"
        f"整城几何覆盖：{coverage:.2%}\n"
        f"晴朗主景云量上限：{task.max_cloud:g}%\n"
        f"边缘补景：{edge_count} 景；仅在严格低云瓦片未覆盖的地方补齐。\n"
        f"边缘补景云量上限：{edge_limit:g}%\n"
        "整城加权云量是用各景元数据和新增覆盖面积估计，不等于逐像素云量。\n",
        encoding="utf-8")
    paths = []
    for index, item in enumerate(selected, 1):
        check_stop(stop)
        progress("download", f"第 {index}/{len(selected)} 景：{item['id']}", 0)
        paths.append(download_scene(item, folder, session, stop, progress))
    if task.mosaic:
        output = folder / (safe_name(task.city) + f"_{day}_自然色_10m_完整影像.tif")
        preview = folder / (safe_name(task.city) + f"_{day}_预览.jpg")
        selection_file = folder / "已拼接景号.json"
        selection = [item["id"] for item in selected]
        previous = (json.loads(selection_file.read_text(encoding="utf-8"))
                    if selection_file.exists() else None)
        if not valid_tiff(output) or previous != selection:
            mosaic_scenes(paths, city_geometry, output, preview, stop, progress)
            selection_file.write_text(json.dumps(selection, ensure_ascii=False, indent=2),
                                      encoding="utf-8")
        return output
    return folder
