"""Desktop interface for multi-city, multi-period Sentinel-2 downloads."""

from __future__ import annotations

import os
import json
import queue
import threading
import tkinter as tk
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from sentinel_batch_core import Stopped, Task, run_task


DEFAULT_ROOT = Path(r"E:\桌面\新建文件夹 (3)\数据\卫星影像_批量")
REGIONS_FILE = Path(__file__).with_name("china_regions.json")


class App:
    def __init__(self, window: tk.Tk) -> None:
        self.window = window
        self.events: queue.Queue[tuple] = queue.Queue()
        self.stop_event = threading.Event()
        self.worker: threading.Thread | None = None
        self.tasks: dict[str, Task] = {}
        self.completed = 0
        self.total = 0
        self.current_task_id: str | None = None
        self.regions: dict[str, list[str]] = json.loads(REGIONS_FILE.read_text(encoding="utf-8"))
        self.selected_regions: list[str] = []
        self.selected_periods: list[tuple[str, str]] = []

        window.title("Sentinel-2 城市卫星影像批量下载与拼接")
        window.geometry("990x760")
        window.minsize(830, 650)
        self.canvas = tk.Canvas(window, highlightthickness=0)
        page_scroll = ttk.Scrollbar(window, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=page_scroll.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        page_scroll.pack(side="right", fill="y")
        outer = ttk.Frame(self.canvas, padding=14)
        canvas_item = self.canvas.create_window((0, 0), window=outer, anchor="nw")
        outer.bind("<Configure>", lambda _event: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda event: self.canvas.itemconfigure(canvas_item, width=event.width))
        window.bind_all("<MouseWheel>", self.scroll_page)
        outer.columnconfigure(0, weight=1)

        title = ttk.Label(outer, text="Sentinel-2 自然色卫星影像 · 10 米", font=("Microsoft YaHei UI", 14, "bold"))
        title.grid(row=0, column=0, sticky="w", pady=(0, 10))

        inputs = ttk.LabelFrame(outer, text="点选地区与时间", padding=10)
        inputs.grid(row=1, column=0, sticky="ew")
        inputs.columnconfigure(0, weight=1)
        inputs.columnconfigure(1, weight=1)
        ttk.Label(inputs, text="地区：先选省份，再选城市").grid(row=0, column=0, sticky="w")
        ttk.Label(inputs, text="时间：分别选择开始、结束日期").grid(row=0, column=1, sticky="w")

        region_picker = ttk.Frame(inputs)
        region_picker.grid(row=1, column=0, sticky="ew", padx=(0, 10), pady=5)
        self.province = ttk.Combobox(region_picker, values=list(self.regions), width=18, state="readonly")
        self.province.pack(side="left")
        self.province.bind("<<ComboboxSelected>>", self.update_city_choices)
        self.city = ttk.Combobox(region_picker, width=18, state="readonly")
        self.city.pack(side="left", padx=6)
        ttk.Button(region_picker, text="加入地区", command=self.add_region).pack(side="left")
        self.province.set("广东省")
        self.update_city_choices()
        self.city.set("广州市")

        today = datetime.now(timezone(timedelta(hours=8))).date()
        date_picker = ttk.Frame(inputs)
        date_picker.grid(row=1, column=1, sticky="w", pady=5)

        def make_date_row(label: str, value: date) -> tuple[tk.StringVar, tk.StringVar, tk.StringVar]:
            row = ttk.Frame(date_picker)
            row.pack(anchor="w", pady=2)
            ttk.Label(row, text=label, width=5).pack(side="left")
            values = (list(range(2015, max(today.year, 2026) + 1)), list(range(1, 13)), list(range(1, 32)))
            vars_ = (tk.StringVar(value=str(value.year)), tk.StringVar(value=str(value.month)), tk.StringVar(value=str(value.day)))
            for var, choices, width, suffix in zip(vars_, values, (6, 4, 4), ("年", "月", "日")):
                ttk.Combobox(row, textvariable=var, values=choices, width=width, state="readonly").pack(side="left", padx=(0, 2))
                ttk.Label(row, text=suffix).pack(side="left", padx=(0, 5))
            return vars_

        self.start_date = make_date_row("开始", today - timedelta(days=45))
        self.end_date = make_date_row("结束", today)

        ttk.Label(inputs, text="已选地区（可多选）").grid(row=2, column=0, sticky="w")
        ttk.Label(inputs, text="已选时间段（晴朗单日从每段内挑一天）").grid(row=2, column=1, sticky="w")
        self.region_list = tk.Listbox(inputs, height=5, selectmode="extended", exportselection=False)
        self.region_list.grid(row=3, column=0, sticky="ew", padx=(0, 10), pady=4)
        self.period_list = tk.Listbox(inputs, height=5, selectmode="extended", exportselection=False)
        self.period_list.grid(row=3, column=1, sticky="ew", pady=4)
        pick_actions = ttk.Frame(inputs)
        pick_actions.grid(row=4, column=0, columnspan=2, sticky="ew")
        ttk.Button(pick_actions, text="移除选中地区", command=self.remove_regions).pack(side="left")
        ttk.Button(pick_actions, text="加入时间段", command=self.add_period).pack(side="left", padx=(18, 6))
        ttk.Button(pick_actions, text="移除选中时间段", command=self.remove_periods).pack(side="left")
        self.selected_periods.append((str(today - timedelta(days=45)), str(today)))
        self.period_list.insert("end", f"{today - timedelta(days=45)} 至 {today}")

        options = ttk.Frame(inputs)
        options.grid(row=5, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        ttk.Label(options, text="主景云量上限 (%)").pack(side="left")
        self.cloud = ttk.Entry(options, width=6)
        self.cloud.insert(0, "1")
        self.cloud.pack(side="left", padx=(5, 18))
        ttk.Label(options, text="选片方式").pack(side="left")
        self.pick = ttk.Combobox(options, values=["晴朗单日", "最近日期", "多日期去云"], width=12, state="readonly")
        self.pick.set("晴朗单日")
        self.pick.pack(side="left", padx=(5, 12))
        ttk.Label(options, text="最多景数").pack(side="left")
        self.max_scenes = ttk.Combobox(options, values=["8", "12", "20", "40", "80"], width=4, state="readonly")
        self.max_scenes.set("12")
        self.max_scenes.pack(side="left", padx=(5, 12))
        self.mosaic = tk.BooleanVar(value=True)
        ttk.Checkbutton(options, text="下载后拼接完整影像", variable=self.mosaic).pack(side="left")
        self.pick_hint = ttk.Label(inputs, foreground="#555555")
        self.pick_hint.grid(row=6, column=0, columnspan=2, sticky="w", pady=(6, 0))
        self.pick.bind("<<ComboboxSelected>>", self.update_pick_options)
        self.update_pick_options()

        actions = ttk.Frame(inputs)
        actions.grid(row=7, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        self.add_button = ttk.Button(actions, text="添加所有城市 × 时间组合", command=self.add_tasks)
        self.add_button.pack(side="left")
        self.remove_button = ttk.Button(actions, text="删除选中任务", command=self.remove_selected)
        self.remove_button.pack(side="left", padx=8)
        self.clear_button = ttk.Button(actions, text="清空任务", command=self.clear_tasks)
        self.clear_button.pack(side="left")
        ttk.Label(actions, text="同一城市可配多个时段；不想要的组合可单独删除。", foreground="#555555").pack(side="left", padx=16)

        path_frame = ttk.Frame(outer)
        path_frame.grid(row=2, column=0, sticky="ew", pady=(12, 6))
        path_frame.columnconfigure(1, weight=1)
        ttk.Label(path_frame, text="保存位置").grid(row=0, column=0, sticky="w")
        self.root_path = tk.StringVar(value=str(DEFAULT_ROOT))
        ttk.Entry(path_frame, textvariable=self.root_path).grid(row=0, column=1, sticky="ew", padx=7)
        ttk.Button(path_frame, text="选择…", command=self.choose_folder).grid(row=0, column=2)
        ttk.Button(path_frame, text="打开", command=self.open_folder).grid(row=0, column=3, padx=(7, 0))

        task_frame = ttk.LabelFrame(outer, text="下载任务", padding=7)
        task_frame.grid(row=3, column=0, sticky="nsew")
        task_frame.columnconfigure(0, weight=1)
        task_frame.rowconfigure(0, weight=1)
        self.tree = ttk.Treeview(task_frame, columns=("city", "start", "end", "cloud", "pick", "scenes", "mosaic", "status"), show="headings", selectmode="extended", height=8)
        for key, label, width in [("city", "地区", 180), ("start", "开始", 95), ("end", "结束", 95),
                                  ("cloud", "云量≤", 65), ("pick", "选片", 95), ("scenes", "最多景数", 75),
                                  ("mosaic", "拼接", 55), ("status", "状态", 150)]:
            self.tree.heading(key, text=label)
            self.tree.column(key, width=width, stretch=key in ("city", "status"))
        self.tree.grid(row=0, column=0, sticky="nsew")
        tree_scroll = ttk.Scrollbar(task_frame, orient="vertical", command=self.tree.yview)
        tree_scroll.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=tree_scroll.set)

        controls = ttk.Frame(outer)
        controls.grid(row=4, column=0, sticky="ew", pady=(12, 6))
        self.start_button = ttk.Button(controls, text="开始批量下载", command=self.start)
        self.start_button.pack(side="left")
        self.stop_button = ttk.Button(controls, text="停止（保留已下载部分）", command=self.stop, state="disabled")
        self.stop_button.pack(side="left", padx=8)
        self.summary = ttk.Label(controls, text="等待添加任务")
        self.summary.pack(side="left", padx=16)

        progress_frame = ttk.LabelFrame(outer, text="进度", padding=8)
        progress_frame.grid(row=5, column=0, sticky="ew")
        progress_frame.columnconfigure(0, weight=1)
        self.current_label = ttk.Label(progress_frame, text="当前任务：未开始")
        self.current_label.grid(row=0, column=0, sticky="w")
        self.stage_bar = ttk.Progressbar(progress_frame, maximum=100)
        self.stage_bar.grid(row=1, column=0, sticky="ew", pady=(4, 10))
        self.all_label = ttk.Label(progress_frame, text="总任务：0 / 0")
        self.all_label.grid(row=2, column=0, sticky="w")
        self.all_bar = ttk.Progressbar(progress_frame, maximum=100)
        self.all_bar.grid(row=3, column=0, sticky="ew", pady=(4, 0))

        log_frame = ttk.LabelFrame(outer, text="运行记录", padding=7)
        log_frame.grid(row=6, column=0, sticky="nsew", pady=(8, 0))
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        self.log = tk.Text(log_frame, height=6, state="disabled", wrap="word")
        self.log.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.log.configure(yscrollcommand=scroll.set)
        ttk.Label(outer, text="影像：Copernicus Sentinel-2 / Earth Search；地区列表：DataV GeoAtlas；行政边界：© OpenStreetMap contributors。",
                  foreground="#555555").grid(row=7, column=0, sticky="w", pady=(6, 0))

        window.protocol("WM_DELETE_WINDOW", self.close)
        window.after(150, self.poll)

    def append_log(self, message: str) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", message + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def scroll_page(self, event) -> None:
        self.canvas.yview_scroll(-int(event.delta / 120), "units")

    def update_city_choices(self, _event=None) -> None:
        choices = self.regions.get(self.province.get(), [])
        self.city.configure(values=choices)
        self.city.set(choices[0] if choices else "")

    def update_pick_options(self, _event=None) -> None:
        cloud_free = self.pick.get() == "多日期去云"
        self.max_scenes.configure(state="readonly" if cloud_free else "disabled")
        self.cloud.configure(state="disabled" if cloud_free else "normal")
        if cloud_free:
            hint = "多日期去云会下载云分类图并局部补云，耗时更长；最多景数在此模式生效。"
        elif self.pick.get() == "晴朗单日":
            hint = "优先选低于上限的同日主景；只缺边缘时允许同日补景高 1 个百分点，不逐像素去云。"
        else:
            hint = "从所选时间段中挑最近的、符合云量上限且覆盖全城的一天。"
        self.pick_hint.configure(text=hint)

    def add_region(self) -> None:
        province, city = self.province.get(), self.city.get()
        if not province or not city:
            return
        name = city if province == city else province + city
        if name not in self.selected_regions:
            self.selected_regions.append(name)
            self.region_list.insert("end", f"{province} · {city}")

    def remove_regions(self) -> None:
        for index in reversed(self.region_list.curselection()):
            self.region_list.delete(index)
            del self.selected_regions[index]

    def add_period(self) -> None:
        try:
            start = date(*(int(var.get()) for var in self.start_date))
            end = date(*(int(var.get()) for var in self.end_date))
            if start > end:
                raise ValueError("开始日期不能晚于结束日期。")
            pair = (str(start), str(end))
            if pair not in self.selected_periods:
                self.selected_periods.append(pair)
                self.period_list.insert("end", f"{start} 至 {end}")
        except Exception as exc:
            messagebox.showerror("日期有误", str(exc))

    def remove_periods(self) -> None:
        for index in reversed(self.period_list.curselection()):
            self.period_list.delete(index)
            del self.selected_periods[index]

    def add_tasks(self) -> None:
        try:
            cities = self.selected_regions
            periods = self.selected_periods
            cloud_free = self.pick.get() == "多日期去云"
            cloud = 100.0 if cloud_free else float(self.cloud.get())
            max_scenes = int(self.max_scenes.get()) if cloud_free else 12
            if not 0 <= cloud <= 100:
                raise ValueError("云量上限应为 0 到 100。")
            if not cities or not periods:
                raise ValueError("请先加入至少一个地区和一个时间段。")
            if len(cities) * len(periods) > 50:
                raise ValueError("一次最多添加 50 个组合，请分批添加。")
            existing = set(self.tasks.values())
            added = 0
            for city in cities:
                for start, end in periods:
                    task = Task(city, start, end, cloud,
                                {"晴朗单日": "least_cloud", "多日期去云": "cloud_free"}.get(self.pick.get(), "latest"),
                                self.mosaic.get(), max_scenes)
                    if task in existing:
                        continue
                    item_id = self.tree.insert("", "end", values=(city, start, end, "自动" if cloud_free else f"{cloud:g}%",
                                                             self.pick.get(), max_scenes if cloud_free else "—",
                                                             "是" if task.mosaic else "否", "待开始"))
                    self.tasks[item_id] = task
                    existing.add(task)
                    added += 1
            self.summary.configure(text=f"已添加 {added} 条；队列共 {len(self.tasks)} 条")
        except Exception as exc:
            messagebox.showerror("输入有误", str(exc))

    def remove_selected(self) -> None:
        for item_id in self.tree.selection():
            self.tasks.pop(item_id, None)
            self.tree.delete(item_id)
        self.summary.configure(text=f"队列共 {len(self.tasks)} 条")

    def clear_tasks(self) -> None:
        for item_id in self.tree.get_children():
            self.tree.delete(item_id)
        self.tasks.clear()
        self.summary.configure(text="队列已清空")

    def choose_folder(self) -> None:
        choice = filedialog.askdirectory(initialdir=self.root_path.get(), title="选择下载文件夹")
        if choice:
            self.root_path.set(choice)

    def open_folder(self) -> None:
        path = Path(self.root_path.get())
        path.mkdir(parents=True, exist_ok=True)
        os.startfile(path)

    def start(self) -> None:
        if self.worker and self.worker.is_alive():
            return
        if not self.tasks:
            messagebox.showinfo("没有任务", "请先添加城市与时间组合。")
            return
        root = Path(self.root_path.get().strip())
        if not str(root):
            messagebox.showerror("保存位置", "请选择保存位置。")
            return
        self.stop_event.clear()
        self.completed = 0
        self.total = len(self.tasks)
        self.all_label.configure(text=f"总任务：0 / {self.total}")
        self.all_bar.configure(value=0)
        self.start_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        for button in (self.add_button, self.remove_button, self.clear_button):
            button.configure(state="disabled")
        jobs = list(self.tasks.items())
        self.worker = threading.Thread(target=self.run_queue, args=(jobs, root), daemon=True)
        self.worker.start()

    def stop(self) -> None:
        self.stop_event.set()
        self.stop_button.configure(state="disabled")
        self.summary.configure(text="正在停止，已下载的场景会保留…")

    def close(self) -> None:
        self.stop_event.set()
        self.window.destroy()

    def run_queue(self, jobs: list[tuple[str, Task]], root: Path) -> None:
        root.mkdir(parents=True, exist_ok=True)
        cache = root / "边界缓存"
        finished = 0
        failures = 0
        for item_id, task in jobs:
            if self.stop_event.is_set():
                break
            self.events.put(("task", item_id, task.city, task.start, task.end,
                             task.pick, task.max_cloud))

            def progress(stage: str, message: str, fraction: float) -> None:
                self.events.put(("progress", item_id, stage, message, fraction))

            try:
                output = run_task(task, root, cache, self.stop_event, progress)
                self.events.put(("result", item_id, True, str(output)))
            except Stopped:
                self.events.put(("result", item_id, False, "已停止，可继续"))
                break
            except Exception as exc:
                failures += 1
                self.events.put(("result", item_id, False, str(exc)))
            finished += 1
            self.events.put(("overall", finished))
        self.events.put(("finished", finished, failures))

    def poll(self) -> None:
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "task":
                    _, item_id, city, start, end, pick, cloud = event
                    self.current_task_id = item_id
                    self.tree.set(item_id, "status", "进行中")
                    self.tree.see(item_id)
                    self.current_label.configure(text=f"当前任务：{city}  {start} 至 {end}")
                    self.stage_bar.configure(value=0)
                    mode = {"least_cloud": "晴朗单日", "latest": "最近日期",
                            "cloud_free": "多日期去云"}.get(pick, pick)
                    detail = f"；主景云量<{cloud:g}%" if pick != "cloud_free" else ""
                    self.append_log(f"开始：{city}  {start} 至 {end}  [{mode}{detail}]")
                elif kind == "progress":
                    _, item_id, stage, message, fraction = event
                    self.stage_bar.configure(value=max(0, min(100, fraction * 100)))
                    self.current_label.configure(text=f"{stage}：{message}")
                    if fraction in (0, 1) or (stage == "search" and not message.startswith("检查云层")):
                        self.append_log(message)
                elif kind == "result":
                    _, item_id, success, message = event
                    self.tree.set(item_id, "status", "完成" if success else "失败 / 已停止")
                    self.append_log(("完成：" if success else "未完成：") + message)
                elif kind == "overall":
                    self.completed = event[1]
                    self.all_label.configure(text=f"总任务：{self.completed} / {self.total}")
                    self.all_bar.configure(value=self.completed / self.total * 100)
                elif kind == "finished":
                    _, finished, failures = event
                    self.start_button.configure(state="normal")
                    self.stop_button.configure(state="disabled")
                    for button in (self.add_button, self.remove_button, self.clear_button):
                        button.configure(state="normal")
                    self.summary.configure(text=f"本轮结束：处理 {finished} 条，失败 {failures} 条")
        except queue.Empty:
            pass
        self.window.after(150, self.poll)


if __name__ == "__main__":
    window = tk.Tk()
    App(window)
    window.mainloop()
