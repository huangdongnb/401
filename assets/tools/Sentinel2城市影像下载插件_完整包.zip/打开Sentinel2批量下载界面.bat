@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 (
    echo ERROR: Cannot open the plugin folder.
    pause
    exit /b 1
)
if not exist "sentinel_batch_gui.py" (
    echo ERROR: sentinel_batch_gui.py is missing.
    pause
    exit /b 1
)
if not exist "sentinel_batch_core.py" (
    echo ERROR: sentinel_batch_core.py is missing.
    pause
    exit /b 1
)
if not exist "china_regions.json" (
    echo ERROR: china_regions.json is missing.
    pause
    exit /b 1
)

set "PY_EXE="
set "PY_ARG="
call :try_python "%LOCALAPPDATA%\Programs\Python\Launcher\py.exe" -3
if not defined PY_EXE for /f "delims=" %%P in ('where py.exe 2^>nul') do call :try_python "%%~fP" -3
if not defined PY_EXE for /f "delims=" %%P in ('where python.exe 2^>nul') do call :try_python "%%~fP"
if not defined PY_EXE (
    echo ERROR: No suitable Python with the plugin packages was found.
    echo Required: tkinter requests numpy Pillow shapely pyproj rasterio scipy.
    echo Install these Python packages and try again.
    pause
    exit /b 1
)

if /i "%~1"=="--check" (
    echo READY: Plugin files and Python packages are available.
    echo Python: "%PY_EXE%" %PY_ARG%
    exit /b 0
)
echo Starting Sentinel-2 downloader...
"%PY_EXE%" %PY_ARG% "%~dp0sentinel_batch_gui.py"
if errorlevel 1 (
    echo ERROR: The plugin stopped. Please take a screenshot of this window.
    pause
    exit /b 1
)
exit /b 0

:try_python
if defined PY_EXE exit /b 0
if not exist "%~1" exit /b 0
"%~1" %~2 -c "import tkinter, requests, numpy, PIL, shapely, pyproj, rasterio, scipy" >nul 2>&1
if not errorlevel 1 (
    set "PY_EXE=%~1"
    set "PY_ARG=%~2"
)
exit /b 0
